<?php $__env->startSection('content'); ?>
    <h1>Create your Profile</h1>
    <form method="POST" action="/profiles">

      <?php echo csrf_field(); ?>

        <div class="field">
          <label class="label">First Name</label>
          <div class="control">
            <input class="input <?php echo e($errors->has('first_name') ? 'is-danger' : ''); ?>" type="text" name="first_name" placeholder="First Name" required>
          </div>
        </div>

        <div class="field">
          <label class="label">Last Name</label>
          <div class="control">
            <input class="input" type="text" name="last_name" placeholder="Last Name" required>
          </div>
        </div>

        <div class="field">
          <label class="label">Country</label>
          <div class="control">
            <input class="input" type="text" name="country" placeholder="Country" required>
          </div>
        </div>

        <div class="field">
          <label class="label">City</label>
          <div class="control">
            <input class="input" type="text" name="city" placeholder="City" required>
          </div>
        </div>

        <div class="field">
          <label class="label">Birthdate</label>
          <div class="control">
            <input class="input" type="text" name="birthdate" placeholder="BirthDate" required>
          </div>
        </div>

        <div class="field">
          <div class="control">
            <button type="submit" name="button is-link">Create Profile</button>
          </div>
        </div>

        <?php if($errors->any()): ?>
          <div class="notification is-danger">

            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

          </div>
        <?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/profiles/create.blade.php ENDPATH**/ ?>