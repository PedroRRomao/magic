<?php $__env->startSection('title', 'Decks'); ?>


<?php $__env->startSection('content'); ?>

<h1 class='title '>Edit your deck!</h1>

<form method='POST' action='/decks/<?php echo e($Deck->id); ?>' style='margin-bottom: 1em;'>

  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  <div>
    <label class='label '>Enter your Deck's Name:</label>
    <input type='text' name='Name' placeholder='DeckName' value='<?php echo e($Deck->Name); ?>'>
  </div>
  <br>
  <div>
    <label class='label '>Your Deck's new Description:</label>
    <textarea name='Description' placeholder='Description' value='<?php echo e($Deck->Description); ?>'></textarea>
  </div>
  <br>
  <div>
    <button type='submit' class='button is-link'>Update</button>
  </div>
</form>

<form method='POST' action='/decks/<?php echo e($Deck->id); ?>'>
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>

    <div>
      <button type='submit' class='button is-link'>Delete</button>
    </div>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decks/edit.blade.php ENDPATH**/ ?>