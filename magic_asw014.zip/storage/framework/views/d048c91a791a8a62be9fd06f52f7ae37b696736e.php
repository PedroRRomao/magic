<?php $__env->startSection('title', 'Decks'); ?>


<?php $__env->startSection('content'); ?>

<h1 class='title '>Create your own deck!</h1>

<form method='POST' action='/decks'>
  <?php echo csrf_field(); ?>
  <div class="field">

    <label class="label">Deck Name</label>

    <div class="control">
      <input class="input" type="text" name="Name" placeholder="Name" required>
    </div>
  </div>
  <br>
  <div class="field">

    <label class="label">Your Deck Description</label>

    <div class="control">
      <input class="input" type="text" name="Description" placeholder="Description" required>
    </div>
  </div>
  <br>
  <div>
    <button type='submit' class='button is-link'>Submit</button>
  </div>
  <br>
  <?php if($errors->any()): ?>
  <div class='notification is-danger'>
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decks/create.blade.php ENDPATH**/ ?>