<?php $__env->startSection('content'); ?>

    
    <?php $data = Auth::user()->unreadNotifications; ?>
    
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <h1>DO you want to trade this cards?</h1>
        <div class="row">


        <?php $trader = $notification->first()->data['image_trade']; ?>
        <?php $user_c = $notification->first()->data['image_user']; ?>
        <div class="col-6">
          <img src="/<?php echo e($cards->get($trader)->src); ?>" alt="image">
        </div>
        <div class="col-6">
          <img src="/<?php echo e($cards->get($user_c)->src); ?>" alt="image">
        </div>
      </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <div class="col-6">
        <button type="submit" class='button is-link' style="border-radius: 5px;" value="1">Accept</button>
      </div>
      <div class="col-6">
        <button type="submit" class='button is-link' style="border-radius: 5px;" value="2">Decline</button>
      </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decktrade/trade.blade.php ENDPATH**/ ?>