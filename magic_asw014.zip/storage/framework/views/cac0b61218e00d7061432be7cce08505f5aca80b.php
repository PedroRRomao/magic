<?php $__env->startSection('content'); ?>

  <h1 class="title">Delete Profile</h1>


  <form  method="POST" action="/profiles/<?php echo e($profile->id); ?>">

    <?php echo e(method_field('DELETE')); ?>


    <?php echo e(csrf_field()); ?>


    <div class="field">

      <h1>Do you want to delete your profile?</h1>
    </div>

      <div class="field">
        <div class="control">
          <button type="submit" name="button is-link">Delete Profile</button>
        </div>
      </div>

    </div>

  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/profiles/delete.blade.php ENDPATH**/ ?>