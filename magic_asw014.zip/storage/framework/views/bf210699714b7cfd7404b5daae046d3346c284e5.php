<?php $__env->startSection('title', 'Decks'); ?>


<?php $__env->startSection('content'); ?>
  <div>

    </form>
    <br>
    <h1>Decks</h1>

    <?php if(count($decks) == 0): ?>
      <form method= 'GET' action= 'decks/create'>
        <?php echo csrf_field(); ?>
      <div>
        <button type="submit" class='button is-link' style="border-radius: 5px;">Build a New One</button>
      </div>

    <?php else: ?>
      <ul>
        <?php $__currentLoopData = $decks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Deck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <a href="/decks/<?php echo e($Deck->id); ?>">
              <?php echo e($Deck->Name); ?>

            </a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

    <?php endif; ?>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decks/index.blade.php ENDPATH**/ ?>