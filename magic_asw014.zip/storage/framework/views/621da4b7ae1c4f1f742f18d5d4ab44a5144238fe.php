<?php $__env->startSection('title', 'Decks'); ?>


<?php $__env->startSection('content'); ?>

<h1 class='title '>Congratulations!</h1>
<div>
  <label class=''> You have created your deck, now it's time to add cards.</label>
</div>
<br>
<div>
  <form method='GET' action='/decks'>
    <?php echo csrf_field(); ?>
    <div>
      <button type="submit" class='button is-link' style="border-radius: 5px;">Back to Decks page</button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decks/add.blade.php ENDPATH**/ ?>