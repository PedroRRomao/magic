<?php $__env->startSection('content'); ?>


    <h1 class="title">User Decks:</h1>
    <ul>
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if(is_null($user->deck)): ?>

      <?php else: ?>

        <li><h1><?php echo e($user->name); ?> : <a href="/decks/<?php echo e($user->deck->id); ?>"><?php echo e($user->deck->Name); ?></h1></a></li>
      <?php endif; ?>
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decktrade/index.blade.php ENDPATH**/ ?>