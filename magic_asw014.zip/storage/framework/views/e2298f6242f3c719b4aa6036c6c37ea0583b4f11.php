<?php $__env->startSection('content'); ?>

  <h1 class="title">Edit Profile</h1>


  <form  method="POST" action="/profiles/<?php echo e($profile->id); ?>">

    <?php echo method_field('PATCH'); ?>

    <?php echo csrf_field(); ?>

      <div class="field">
        <label class="label">First Name</label>
        <div class="control">
          <input class="input" type="text" name="first_name" placeholder="First Name" value="<?php echo e($profile->first_name); ?>">
        </div>
      </div>

      <div class="field">
        <label class="label">Last Name</label>
        <div class="control">
          <input class="input" type="text" name="last_name" placeholder="Last Name" value="<?php echo e($profile->last_name); ?>">
        </div>
      </div>

      <div class="field">
        <label class="label">Country</label>
        <div class="control">
          <input class="input" type="text" name="country" placeholder="Country" value="<?php echo e($profile->country); ?>">
        </div>
      </div>

      <div class="field">
        <label class="label">City</label>
        <div class="control">
          <input class="input" type="text" name="city" placeholder="City" value="<?php echo e($profile->city); ?>">
        </div>
      </div>

      <div class="field">
        <label class="label">Birthdate</label>
        <div class="control">
          <input class="input" type="text" name="birthdate" placeholder="BirthDate" value="<?php echo e($profile->birthdate); ?>">
        </div>
      </div>

      <div class="field">
        <div class="control">
          <button type="submit" name="button is-link">Update Profile</button>
        </div>
      </div>



  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/profiles/edit.blade.php ENDPATH**/ ?>