<?php $__env->startSection('content'); ?>

  <h1 class="title"><?php echo e(Auth::user()->name); ?></h1>

  <div class="box"><h1>This user is from: <?php echo e($profile->city); ?></h1>

  </div>

  <div class="box">
    <?php if(is_null($profile->clan)): ?>

    <?php else: ?>
      <h1>Clan: <?php echo e($profile->clan->name); ?></h1>
    <?php endif; ?>
  </div>

  <p>
    <a href="/profiles/<?php echo e($profile->id); ?>/edit">Edit Profile</a>
  </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/profiles/show.blade.php ENDPATH**/ ?>