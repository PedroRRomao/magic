<?php $__env->startSection('title', 'Clans'); ?>


<?php $__env->startSection('content'); ?>
  <div>

    </form>
    <br>
    <h1>Clans</h1>

    <?php if(count($clans) == 0): ?>
      <form method= 'GET' action= 'clans/create'>
        <?php echo csrf_field(); ?>
      <div>
        <button type="submit" class='button is-link' style="border-radius: 5px;">Create a Clan</button>
      </div>

    <?php else: ?>
      <ul>
        <?php $__currentLoopData = $clans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Clan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <p>  <?php echo e($Clan->name); ?> </p>
            <a href="/clans/<?php echo e($Clan->id); ?>">
              Join this Clan
            </a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

    <?php endif; ?>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/clans/index.blade.php ENDPATH**/ ?>