<?php $__env->startSection('title', 'Cards'); ?>


<?php $__env->startSection('content'); ?>

        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php if( $card->id == 1): ?>
            <div class="card">
              <div class="card-body">
                <div class="card-deck">
                  <div class="card">
                    <a href="<?php echo e($card->src); ?>" target="_blank">
                      <img src="<?php echo e($card->src); ?>" alt="Card image cap">
                    </a>

                  </div>

          <?php elseif(($card->id)%5 == 0): ?>

                  <div class="card">
                    <a href="<?php echo e($card->src); ?>" target="_blank">
                      <img src="<?php echo e($card->src); ?>" alt="Card image cap">
                    </a>
                  </div>
                </div>
              </div>
            </div>

          <?php elseif((($card->id)-1)%5 == 0): ?>
            <div class="card">
              <div class="card-body">
                <div class="card-deck">
                  <div class="card">
                    <a href="<?php echo e($card->src); ?>" target="_blank">
                      <img src="<?php echo e($card->src); ?>" alt="Card image cap">
                    </a>
                  </div>
          <?php else: ?>
                  <div class="card">
                    <a href="<?php echo e($card->src); ?>" target="_blank">
                      <img src="<?php echo e($card->src); ?>" alt="Card image cap">
                    </a>
                  </div>
          <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/cards.blade.php ENDPATH**/ ?>