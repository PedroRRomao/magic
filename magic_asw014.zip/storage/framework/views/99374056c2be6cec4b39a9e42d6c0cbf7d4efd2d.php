<?php $__env->startSection('style'); ?>
  <link href="<?php echo e(asset('css/cards.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('trades'); ?>

      <hr>

      <form  method="POST" action="/send/<?php echo e($user_trade->id); ?>">

        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>

        <div class="row">
          <div class='col-6'><h1 class="has-text-white">Your Deck: <?php echo e(Auth::user()->name); ?> </h1>

            <?php $__currentLoopData = $cards_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Cards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php if($loop->first): ?>
                <div class="card">
                  <div class="card-body">
                    <div class="card-deck">
                      <div class="card" id="card">
                        <label class="image-checkbox">
                            <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                            <input type="checkbox" name="cards_user[]" value="<?php echo e($Cards->id); ?>" checked="checked" />
                        </label>

                      </div>

              <?php elseif(($loop->iteration)%5 == 0): ?>

                      <div class="card" id="card">
                        <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                          <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

              <?php elseif((($loop->iteration)-1)%5 == 0): ?>

                <?php if($loop->remaining < 1): ?>

                  <div class="card">
                    <div class="card-body">
                      <div class="card-deck">
                        <div class="card is-clearfix" id="card">
                          <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                            <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                <?php else: ?>

                  <div class="card">
                    <div class="card-body">
                      <div class="card-deck">
                        <div class="card" id="card">
                          <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                            <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                          </a>
                        </div>
                <?php endif; ?>

              <?php else: ?>

                  <?php if($loop->remaining <1): ?>

                        <div class="card is-clearfix" id="card">
                          <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                            <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                <?php else: ?>
                      <div class="card" id="card">
                        <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                          <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                        </a>
                      </div>
                <?php endif; ?>

              <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <div class="col-6"><h1 class="has-text-white">Traders Deck: <?php echo e($user_trade->name); ?> </h1>

            <?php $__currentLoopData = $cards_trader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CardsT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php if($loop->first): ?>
                <div class="card">
                  <div class="card-body">
                    <div class="card-deck">
                      <div class="card" id="card">
                        <label class="image-checkbox">
                            <img src="<?php echo e(URL::asset($CardsT->src)); ?>" alt="Card image cap">
                            <input type="checkbox" name="cards_trader[]" value="<?php echo e($CardsT->id); ?>" checked="checked" />
                        </label>
                      </div>

              <?php elseif(($loop->iteration)%5 == 0): ?>

                      <div class="card" id="card">
                        <a href="<?php echo e(URL::asset($CardsT->src)); ?>" target="_blank">
                          <img src="<?php echo e(URL::asset($CardsT->src)); ?>" alt="Card image cap">
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

              <?php elseif((($loop->iteration)-1)%5 == 0): ?>

                <?php if($loop->remaining < 1): ?>
                  <div class="card">
                    <div class="card-body" id="last_card">
                      <div style="width: 40%" class="card-deck">
                        <div class="card" id="card">
                          <a href="<?php echo e(URL::asset($CardsT->src)); ?>" target="_blank">
                            <img src="<?php echo e(URL::asset($CardsT->src)); ?>" alt="Card image cap">
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                <?php else: ?>

                  <div class="card">
                    <div class="card-body">
                      <div class="card-deck">
                        <div class="card" id="card">
                          <a href="<?php echo e(URL::asset($CardsT->src)); ?>" target="_blank">
                            <img src="<?php echo e(URL::asset($CardsT->src)); ?>" alt="Card image cap">
                          </a>
                        </div>
                <?php endif; ?>

              <?php else: ?>

                  <?php if($loop->remaining <1): ?>

                        <div class="card" id="card">
                          <a href="<?php echo e(URL::asset($CardsT->src)); ?>" target="_blank">
                            <img src="<?php echo e(URL::asset($CardsT->src)); ?>" alt="Card image cap">
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                <?php else: ?>
                      <div class="card" id="card">
                        <a href="<?php echo e(URL::asset($CardsT->src)); ?>" target="_blank">
                          <img src="<?php echo e(URL::asset($CardsT->src)); ?>" alt="Card image cap">
                        </a>
                      </div>
                <?php endif; ?>

              <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



<script type="text/javascript">
  jQuery(function ($) {
      // init the state from the input
      $(".image-checkbox").each(function () {
          if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
              $(this).addClass('image-checkbox-checked');
          }
          else {
              $(this).removeClass('image-checkbox-checked');
          }
      });

      // sync the state to the input
      $(".image-checkbox").on("click", function (e) {
          if ($(this).hasClass('image-checkbox-checked')) {
              $(this).removeClass('image-checkbox-checked');
              $(this).find('input[type="checkbox"]').first().removeAttr("checked");
          }
          else {
              $(this).addClass('image-checkbox-checked');
              $(this).find('input[type="checkbox"]').first().attr("checked", "checked");
          }

          e.preventDefault();
      });
  });
</script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="control">
      <button type="submit" name="button is-link">Ask for Trade</button>
    </div>



</form>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decktrade/edit.blade.php ENDPATH**/ ?>