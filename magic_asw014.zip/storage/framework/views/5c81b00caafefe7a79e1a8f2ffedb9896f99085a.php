<?php $__env->startSection('title', 'Decks'); ?>


<?php $__env->startSection('content'); ?>

<h1 class='title '>You have deleted your deck succesfully.</h1>
<br>
<form method= 'GET' action= '/decks'>
  <?php echo csrf_field(); ?>

<div>
  <button type="submit" class='button is-link' style="border-radius: 5px;">Back to Decks page</button>
</div>
</form>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decks/delete.blade.php ENDPATH**/ ?>