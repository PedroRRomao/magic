<?php $__env->startSection('content'); ?>


    <h1 class="title">Profile:</h1>
    <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <li>
        <a href="/profiles/<?php echo e($profile->id); ?>">
          <?php echo e(Auth::user()->name); ?>

        </a>

      </li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/profiles/index.blade.php ENDPATH**/ ?>