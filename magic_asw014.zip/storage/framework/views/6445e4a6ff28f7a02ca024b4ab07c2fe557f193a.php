<?php $__env->startSection('title', 'Decks'); ?>


<?php $__env->startSection('content'); ?>

<h1 class='title'><?php echo e($Deck->Name); ?></h1>
<div class='content'><?php echo e($Deck->Description); ?>


</div>
<?php if(Auth::user()->id == $Deck->owner_id): ?>
<form method= 'GET' action= '/decks/<?php echo e($Deck->owner_id); ?>/edit'>
  <?php echo csrf_field(); ?>
  <div>
  <button type='submit' class='has-text-white button is-link'>Edit Deck Name</button>
 </div>
</form>
<?php else: ?>
  <form method= 'GET' action= '/decktrade/<?php echo e(Auth::user()->deck->owner_id); ?>/trade/<?php echo e($Deck->owner_id); ?>'>
    <?php echo csrf_field(); ?>
    <div>
    <button type='submit' class='has-text-white button is-link'>Trade</button>
   </div>
  </form>
<?php endif; ?>

<br>
<br>
<div class="card">
    <div class="card-header has-text-dark">Deck Cards</div>
      <div class="card-body">
          <?php $__currentLoopData = $Card; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Cards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($loop->first): ?>
              <div class="card">
                <div class="card-body">
                  <div class="card-deck">
                    <div class="card">
                      <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                        <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                      </a>

                    </div>

            <?php elseif(($loop->iteration)%3 == 0): ?>

                    <div class="card">
                      <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                        <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                      </a>
                    </div>
                  </div>
                </div>
              </div>

            <?php elseif((($loop->iteration)-1)%3 == 0): ?>
              <div class="card">
                <div class="card-body">
                  <div class="card-deck">
                    <div class="card">
                      <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                        <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                      </a>
                    </div>
            <?php else: ?>
                    <div class="card">
                      <a href="<?php echo e(URL::asset($Cards->src)); ?>" target="_blank">
                        <img src="<?php echo e(URL::asset($Cards->src)); ?>" alt="Card image cap">
                      </a>
                    </div>
            <?php endif; ?>

            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/decks/show.blade.php ENDPATH**/ ?>