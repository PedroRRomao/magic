<?php $__env->startSection('content'); ?>

  <div class="container has-text-centered">
      <div class="center-logo">
              <figure class="image">
                  <img src="/img/logo.png">
              </figure>
      </div>
  </div>

  <style media="screen">
  .center-logo {
    display: block;
    margin-left: 22%;
    margin-right: auto;
    margin-top: 10%;
    width: 50%;
    }
  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/welcome.blade.php ENDPATH**/ ?>