<?php echo e($slot); ?>

<?php /**PATH /home/pedro/Desktop/asw/repository/magic/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>