<?php $__env->startSection('title', 'Rules'); ?>





<?php $__env->startSection('content'); ?>
  <h1>Rules</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pedro/Desktop/asw/repository/magic/resources/views/rules.blade.php ENDPATH**/ ?>