@extends('layouts.app')

@section('content')


    <h1 class="title">Trading Offer</h1>
  


@endsection
