@extends('layouts.layout')



@section('title', 'Rules')





@section('content')
  <h1>Rules</h1>
@endsection
