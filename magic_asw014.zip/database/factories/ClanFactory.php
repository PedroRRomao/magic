<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Clan;
use Faker\Generator as Faker;

$factory->define(Clan::class, function (Faker $faker) {
    return [
        //
    ];
});
