<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Card;
use Faker\Generator as Faker;

$factory->define(Card::class, function (Faker $faker) {
    return [
        //
    ];
});
